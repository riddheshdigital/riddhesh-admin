const USER = "admin";
const PASS = "1234"; // change this

function login() {
  if (user.value === USER && pass.value === PASS) {
    document.getElementById("panel").style.display = "block";
    load();
  } else {
    alert("Invalid login");
  }
}

// function load() {
//   fetch("../data/content.json")
//     .then(r => r.json())
//     .then(d => {
//       title.value = d.title;
//       desc.value = d.description;
//     });
// }
