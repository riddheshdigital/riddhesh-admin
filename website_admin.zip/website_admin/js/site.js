fetch("data/content.json")
  .then(res => res.json())
  .then(data => {
    document.getElementById("title").innerText = data.title;
    document.getElementById("desc").innerText = data.description;
  });
